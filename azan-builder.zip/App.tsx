import React, { useState, useEffect } from 'react';
import HomePage from './pages/HomePage';
import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import BuilderPage from './pages/BuilderPage';
import { Page, GeneratedCode } from './types';

const App: React.FC = () => {
  const [page, setPage] = useState<Page>('home');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [generatedCode, setGeneratedCode] = useState<GeneratedCode | null>(null);
  const [userPrompt, setUserPrompt] = useState('');
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});


  const handleLogin = () => {
    setIsAuthenticated(true);
    setPage('dashboard');
  };

  const handleCodeGenerated = (prompt: string, code: GeneratedCode, answers: Record<string, string>) => {
    setUserPrompt(prompt);
    setGeneratedCode(code);
    setUserAnswers(answers);
    setPage('builder');
  };

  const handleStartNewProject = () => {
    setGeneratedCode(null);
    setUserPrompt('');
    setUserAnswers({});
    setPage('dashboard');
  };

  const renderPage = () => {
    if (!isAuthenticated) {
      switch (page) {
        case 'home':
          return <HomePage onGetStarted={() => setPage('auth')} />;
        case 'auth':
          return <AuthPage onLogin={handleLogin} />;
        default:
          return <HomePage onGetStarted={() => setPage('auth')} />;
      }
    }

    switch (page) {
      case 'dashboard':
        return <DashboardPage onCodeGenerated={handleCodeGenerated} />;
      case 'builder':
        return generatedCode ? (
          <BuilderPage 
            initialCode={generatedCode} 
            userPrompt={userPrompt} 
            answers={userAnswers}
            onNewProject={handleStartNewProject}
          />
        ) : (
          <DashboardPage onCodeGenerated={handleCodeGenerated} />
        );
      default:
        return <DashboardPage onCodeGenerated={handleCodeGenerated} />;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {renderPage()}
    </div>
  );
};

export default App;
