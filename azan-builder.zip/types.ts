export type Page = 'home' | 'auth' | 'dashboard' | 'builder';

export type Device = 'mobile' | 'tablet' | 'desktop';

export type GeneratedCode = Record<string, string>;

export interface Question {
  id: string;
  text: string;
}
