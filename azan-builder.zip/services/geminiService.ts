import { GoogleGenAI, Type } from "@google/genai";
import { GeneratedCode, Question } from '../types';

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  // In a real app, you'd handle this more gracefully.
  // For this environment, we assume API_KEY is set.
  console.warn("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const getClarifyingQuestions = async (prompt: string): Promise<Question[]> => {
  try {
    const fullPrompt = `A user wants to build a project. Their initial prompt is: "${prompt}". 
    Generate 3 concise, critical follow-up questions to understand their core needs. 
    Focus on functionality, technology stack (if any preference), and overall goal.
    Return a JSON object with a 'questions' array.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      contents: fullPrompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: {
                    type: Type.STRING,
                    description: "A unique identifier for the question, e.g., 'q1'"
                  },
                  text: {
                    type: Type.STRING,
                    description: "The text of the clarifying question."
                  }
                },
                required: ["id", "text"]
              }
            }
          },
          required: ["questions"]
        }
      }
    });

    const jsonResponse = JSON.parse(response.text);
    return jsonResponse.questions || [];
  } catch (error) {
    console.error("Error getting clarifying questions:", error);
    // Fallback questions
    return [
        { id: 'q1', text: 'What is the main purpose of this project?' },
        { id: 'q2', text: 'What are the key features you need?' },
        { id: 'q3', text: 'Who is the target audience for this project?' },
    ];
  }
};


export const generateProjectCode = async (prompt: string, answers: Record<string, string>): Promise<GeneratedCode> => {
    const framework = answers.framework_choice || 'html_css_js';
    let frameworkInstructions = '';
    
    switch (framework) {
        case 'react':
            frameworkInstructions = `Generate code for a modern React application using Vite. Include 'index.html', 'src/main.jsx', 'src/App.jsx', and 'src/index.css'. The index.html should be minimal and link to main.jsx. App.jsx should contain the main component logic. Add TailwindCSS via CDN in index.html for styling.`;
            break;
        case 'vue':
            frameworkInstructions = `Generate code for a modern Vue 3 application using Vite. Include 'index.html', 'src/main.js', 'src/App.vue', and 'src/style.css'. The index.html should link to main.js. App.vue should be a Single File Component with template, script, and style blocks. Add TailwindCSS via CDN in index.html for styling.`;
            break;
        case 'single_html':
            frameworkInstructions = `Generate a single 'index.html' file. All CSS must be inside a <style> tag in the <head>, and all JavaScript must be inside a <script> tag before the closing </body> tag. Do not create separate .css or .js files. You can use TailwindCSS via CDN.`;
            break;
        default: // html_css_js
            frameworkInstructions = `Create all necessary files. For a standard website, this must include 'index.html', 'style.css', and 'script.js'. The HTML should link to the CSS and JS files.`;
            break;
    }

    const detailedPrompt = `
      User request: "${prompt}"
      User's answers:
      ${Object.entries(answers).map(([key, value]) => `- ${key}: ${value}`).join('\n')}

      Project Format Instructions: ${frameworkInstructions}

      Based on all the information above, generate a complete set of files for the project.
      - Write professional, clean, and functional code for each file.
      - If styling is not specified for a website, default to a modern, responsive, black and white theme.
      - For projects needing APIs (Image/Video Generator, Chatbot), create mock UIs and placeholder JS functions to demonstrate integration.
      - Return a JSON object containing a "files" array, where each object in the array has a "name" (string, e.g., "index.html") and a "content" (string).
    `;
    
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            contents: detailedPrompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        files: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    name: { type: Type.STRING },
                                    content: { type: Type.STRING }
                                },
                                required: ["name", "content"]
                            }
                        }
                    },
                    required: ["files"]
                }
            }
        });

        const jsonResponse = JSON.parse(response.text);
        const generatedCode: GeneratedCode = {};
        for (const file of jsonResponse.files) {
            generatedCode[file.name] = file.content;
        }
        return generatedCode;
    } catch (error) {
        console.error("Error generating project code:", error);
        return {
            "error.txt": `Error Generating Code\n\nThere was an issue generating the code. Please try again.\n\nDetails: ${error.message}`
        };
    }
};


export const regenerateProjectCode = async (originalPrompt: string, answers: Record<string, string>, currentCode: GeneratedCode, changeRequest: string): Promise<GeneratedCode> => {
  const detailedPrompt = `
      The user wants to modify an existing project.
      
      Original Request: "${originalPrompt}"
      Original Clarifications:
      ${Object.entries(answers).map(([key, value]) => `- ${key}: ${value}`).join('\n')}

      Current Files and Code:
      ${Object.entries(currentCode).map(([name, content]) => `
      --- FILE: ${name} ---
      ${content}
      --------------------
      `).join('\n')}

      User's Change Request: "${changeRequest}"

      Based on the change request, modify the existing files. You can add, remove, or edit files.
      Return the COMPLETE new set of files, maintaining the original file structure and framework choice unless explicitly asked to change it.
      The output must be a JSON object containing a "files" array, where each object has a "name" (string) and "content" (string).
  `;

  try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            contents: detailedPrompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        files: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    name: { type: Type.STRING },
                                    content: { type: Type.STRING }
                                },
                                required: ["name", "content"]
                            }
                        }
                    },
                    required: ["files"]
                }
            }
        });

        const jsonResponse = JSON.parse(response.text);
        const generatedCode: GeneratedCode = {};
        for (const file of jsonResponse.files) {
            generatedCode[file.name] = file.content;
        }
        return generatedCode;
    } catch (error) {
        console.error("Error regenerating project code:", error);
        return {
            ...currentCode,
            "error.txt": `Error Applying Changes\n\nThere was an issue regenerating the code. Please check your request and try again.\n\nDetails: ${error.message}`
        };
    }
};