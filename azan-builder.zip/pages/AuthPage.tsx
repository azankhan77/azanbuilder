
import React, { useState } from 'react';

interface AuthPageProps {
  onLogin: () => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-black">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold tracking-tighter">Azan Builder</h1>
          <p className="text-gray-400 mt-2">Welcome back. Or get started now.</p>
        </div>

        <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-8 shadow-2xl shadow-gray-900/50">
          <div className="flex border-b border-gray-700 mb-6">
            <button 
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-3 font-semibold text-center transition-colors ${isLogin ? 'text-white border-b-2 border-white' : 'text-gray-500 hover:text-white'}`}
            >
              Login
            </button>
            <button 
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-3 font-semibold text-center transition-colors ${!isLogin ? 'text-white border-b-2 border-white' : 'text-gray-500 hover:text-white'}`}
            >
              Sign Up
            </button>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); onLogin(); }}>
            <div className="space-y-6">
              <div>
                <label className="text-sm font-medium text-gray-400" htmlFor="email">Email</label>
                <input 
                  type="email" 
                  id="email" 
                  placeholder="you@example.com"
                  className="w-full mt-2 p-3 bg-gray-800 border border-gray-700 rounded-md focus:ring-2 focus:ring-white focus:outline-none"
                  required 
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-400" htmlFor="password">Password</label>
                <input 
                  type="password" 
                  id="password" 
                  placeholder="••••••••"
                  className="w-full mt-2 p-3 bg-gray-800 border border-gray-700 rounded-md focus:ring-2 focus:ring-white focus:outline-none"
                  required 
                />
              </div>
            </div>
            <button 
              type="submit"
              className="w-full mt-8 py-3 px-6 bg-white text-black font-bold rounded-md hover:bg-gray-200 transition-colors"
            >
              {isLogin ? 'Login' : 'Create Account'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
