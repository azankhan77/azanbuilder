import React from 'react';
import Footer from '../components/Footer';
import Icon from '../components/Icon';

interface HomePageProps {
  onGetStarted: () => void;
}

const HomePage: React.FC<HomePageProps> = ({ onGetStarted }) => {
  return (
    <div className="flex flex-col min-h-screen bg-black">
      <div className="absolute inset-0 z-0 opacity-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(255,255,255,0.2)_0,_rgba(255,255,255,0)_80%)]"></div>
      </div>

      <header className="p-4 sm:p-6 lg:p-8">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold tracking-tighter">Azan Builder</h1>
        </div>
      </header>

      <main className="flex-grow flex flex-col items-center justify-center text-center p-4 z-10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl sm:text-5xl md:text-7xl font-black tracking-tighter mb-4 text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-500">
            Build anything, instantly.
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-gray-400 max-w-2xl mx-auto mb-8">
            From landing pages to complex applications, describe what you need and let our AI bring it to life in seconds.
          </p>
          <button 
            onClick={onGetStarted}
            className="bg-white text-black font-bold py-3 px-8 rounded-full text-lg hover:bg-gray-200 transition-transform transform hover:scale-105 group"
          >
            Get Started <Icon name="arrowRight" className="inline-block w-5 h-5 ml-2 transition-transform group-hover:translate-x-1" />
          </button>
        </div>
        
        <div className="w-full max-w-6xl mx-auto mt-16 md:mt-24 px-4">
            <div className="relative rounded-xl shadow-2xl shadow-gray-900/50 border border-white/10 bg-gray-900/50 p-2">
                <div className="aspect-video w-full h-full rounded-lg bg-black bg-[url('https://images.unsplash.com/photo-1678132239420-a63415c18941?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')] bg-cover bg-center">
                    <div className="w-full h-full bg-black/50 flex items-center justify-center p-4">
                       <p className="text-xl sm:text-2xl font-bold text-white/80 text-center">Your Professional Dashboard Awaits</p>
                    </div>
                </div>
            </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default HomePage;