import React, { useState } from 'react';
import { GeneratedCode, Question } from '../types';
import { getClarifyingQuestions, generateProjectCode } from '../services/geminiService';
import Icon from '../components/Icon';

interface DashboardPageProps {
  onCodeGenerated: (prompt: string, code: GeneratedCode, answers: Record<string, string>) => void;
}

type Framework = 'html_css_js' | 'react' | 'vue' | 'single_html';

const frameworks: { id: Framework; name: string }[] = [
    { id: 'html_css_js', name: 'HTML/CSS/JS' },
    { id: 'react', name: 'React' },
    { id: 'vue', name: 'Vue' },
    { id: 'single_html', name: 'Single HTML File' },
];


const DashboardPage: React.FC<DashboardPageProps> = ({ onCodeGenerated }) => {
  const [prompt, setPrompt] = useState('');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [loadingState, setLoadingState] = useState<'idle' | 'fetching_questions' | 'generating_code'>('idle');
  const [error, setError] = useState('');
  const [selectedFramework, setSelectedFramework] = useState<Framework>('html_css_js');
  
  const handleInitialPrompt = async () => {
    if (!prompt.trim()) {
      setError('Please enter a description for your project.');
      return;
    }
    setError('');
    setLoadingState('fetching_questions');
    try {
      const fetchedQuestions = await getClarifyingQuestions(prompt);
      setQuestions(fetchedQuestions);
    } catch(err) {
      setError('Could not fetch clarifying questions. Please try again.');
      console.error(err);
    } finally {
      setLoadingState('idle');
    }
  };

  const handleFinalGeneration = async () => {
    setLoadingState('generating_code');
    setError('');
    try {
        const finalAnswers = { ...answers, framework_choice: selectedFramework };
        const finalCode = await generateProjectCode(prompt, finalAnswers);
        onCodeGenerated(prompt, finalCode, finalAnswers);
    } catch (err) {
        setError('Failed to generate the project code. Please try again.');
        console.error(err);
        setLoadingState('idle');
    }
  };

  const handleAnswerChange = (questionId: string, value: string) => {
    setAnswers(prev => ({...prev, [questionId]: value}));
  };
  
  const allQuestionsAnswered = questions.length > 0 && questions.every(q => answers[q.id] && answers[q.id].trim() !== '');

  const renderContent = () => {
    if (loadingState === 'fetching_questions') {
      return <div className="text-center"><p className="text-xl">Thinking of some smart questions...</p></div>
    }

    if (questions.length > 0) {
      return (
        <div>
          <h2 className="text-2xl font-bold mb-2">Just a few more details...</h2>
          <p className="text-gray-400 mb-6">Your answers will help us create the perfect result.</p>
          <div className="space-y-4">
            {questions.map((q) => (
              <div key={q.id}>
                <label className="block text-sm font-medium text-gray-300 mb-1">{q.text}</label>
                <input 
                  type="text"
                  onChange={(e) => handleAnswerChange(q.id, e.target.value)}
                  className="w-full p-3 bg-gray-800 border border-gray-700 rounded-md focus:ring-2 focus:ring-white focus:outline-none"
                />
              </div>
            ))}
          </div>
          
          <div className="mt-6">
             <label className="block text-sm font-medium text-gray-300 mb-2">Select Output Format</label>
             <div className="grid grid-cols-2 gap-2">
                {frameworks.map((fw) => (
                    <button
                        key={fw.id}
                        onClick={() => setSelectedFramework(fw.id)}
                        className={`p-3 text-center border rounded-md transition-colors text-sm ${selectedFramework === fw.id ? 'bg-white text-black border-white' : 'border-gray-600 hover:bg-gray-700'}`}
                    >
                        {fw.name}
                    </button>
                ))}
             </div>
          </div>

          <button 
            onClick={handleFinalGeneration}
            disabled={!allQuestionsAnswered || loadingState === 'generating_code'}
            className="w-full mt-6 py-3 px-6 bg-white text-black font-bold rounded-md hover:bg-gray-200 transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed"
          >
            {loadingState === 'generating_code' ? 'Building your project...' : 'Generate Project'}
          </button>
        </div>
      );
    }

    return (
      <div>
        <h2 className="text-2xl font-bold mb-2">What would you like to build today?</h2>
        <p className="text-gray-400 mb-6">Describe any Website, Tool, App, or Software.</p>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., A modern portfolio website for a freelance photographer named Jane Doe."
          className="w-full h-32 p-4 bg-gray-800 border border-gray-700 rounded-md focus:ring-2 focus:ring-white focus:outline-none resize-none"
        />
        <button 
          onClick={handleInitialPrompt}
          className="w-full mt-4 py-3 px-6 bg-white text-black font-bold rounded-md hover:bg-gray-200 transition-colors"
        >
          Start Generating
        </button>
      </div>
    );
  };

  return (
    <div className="flex items-center justify-center min-h-screen p-4 bg-black">
      <div className="w-full max-w-2xl mx-auto">
        <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-8 shadow-2xl shadow-gray-900/50">
          {error && <p className="text-red-500 mb-4">{error}</p>}
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;