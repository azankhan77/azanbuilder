import React, { useState, useMemo, useEffect } from 'react';
import { GeneratedCode, Device } from '../types';
import { regenerateProjectCode } from '../services/geminiService';
import Icon from '../components/Icon';

interface BuilderPageProps {
  initialCode: GeneratedCode;
  userPrompt: string;
  answers: Record<string, string>;
  onNewProject: () => void;
}

const BuilderPage: React.FC<BuilderPageProps> = ({ initialCode, userPrompt, answers, onNewProject }) => {
  const [code, setCode] = useState<GeneratedCode>(initialCode);
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
  const [device, setDevice] = useState<Device>('desktop');
  const [activeFile, setActiveFile] = useState<string>(Object.keys(initialCode)[0] || '');
  const [changeRequest, setChangeRequest] = useState('');
  const [isRegenerating, setIsRegenerating] = useState(false);

  useEffect(() => {
    const fileNames = Object.keys(code);
    if (!fileNames.includes(activeFile) || !activeFile) {
        setActiveFile(fileNames.find(name => name.toLowerCase().includes('app') || name.toLowerCase().includes('index')) || fileNames[0] || '');
    }
  }, [code, activeFile]);
  
  const projectType = useMemo(() => {
    const fileNames = Object.keys(code);
    if (fileNames.some(name => name.endsWith('.jsx'))) return 'react';
    if (fileNames.some(name => name.endsWith('.vue'))) return 'vue';
    return 'html';
  }, [code]);

  const previewContent = useMemo(() => {
    if (projectType !== 'html') {
      return `
        <html>
          <head>
            <style>
              body { background-color:#111; color:white; font-family: sans-serif; padding: 2rem; display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100vh; margin: 0; box-sizing: border-box; }
              h1 { font-size: 1.5rem; text-align: center; margin-bottom: 1rem; }
              p { text-align: center; max-width: 500px; line-height: 1.6; color: #aaa; }
              .instructions { background-color: #222; padding: 1.5rem; border-radius: 8px; margin-top: 2rem; font-family: monospace; max-width: 90%; width: 500px; }
              .instructions p { text-align: left; margin-bottom: 1rem; color: #eee; }
              .instructions ol { margin: 0; padding-left: 20px; }
              .instructions li { margin-bottom: 0.5rem; }
              strong { color: #87CEEB; }
            </style>
          </head>
          <body>
            <h1>${projectType.charAt(0).toUpperCase() + projectType.slice(1)} Project Generated</h1>
            <p>Live preview for this project type requires a local development server.</p>
            <div class="instructions">
              <p>To run this project:</p>
              <ol>
                <li>Download the project files.</li>
                <li>Open a terminal in the project folder.</li>
                <li>Run <strong>npm install</strong></li>
                <li>Run <strong>npm run dev</strong></li>
              </ol>
            </div>
          </body>
        </html>
      `;
    }

    const html = code['index.html'] || '<body style="background-color:#111; color:white; font-family: sans-serif; padding: 2rem;"><h1>No index.html found</h1><p>Preview is only available for web projects.</p></body>';
    
    // For single file html, all is self-contained.
    if (answers.framework_choice === 'single_html') {
        return html;
    }

    const css = code['style.css'] || '';
    const js = code['script.js'] || '';

    return `
      <html>
        <head>
          <style>${css}</style>
          <script src="https://cdn.tailwindcss.com"></script>
        </head>
        <body>
          ${html}
          <script>${js}</script>
        </body>
      </html>
    `;
  }, [code, projectType, answers]);

  const deviceWidths: Record<Device, string> = {
    desktop: '100%',
    tablet: '768px',
    mobile: '375px',
  };

  const handleDownload = () => {
    alert("Project download initiated! (This is a demo feature)");
  };
  
  const handleReload = () => {
    const iframe = document.getElementById('preview-iframe') as HTMLIFrameElement;
    if (iframe) {
        iframe.srcdoc = previewContent;
    }
  };

  const handleRegenerate = async () => {
    if (!changeRequest.trim()) return;
    setIsRegenerating(true);
    const newCode = await regenerateProjectCode(userPrompt, answers, code, changeRequest);
    setCode(newCode);
    setChangeRequest('');
    setIsRegenerating(false);
    setViewMode('preview');
  };

  const CodeEditor: React.FC = () => {
    if (!activeFile || code[activeFile] === undefined) {
        return <div className="w-full h-full bg-[#1e1e1e] flex items-center justify-center text-gray-500">Select a file to view its content.</div>;
    }
    return (
        <div className="w-full h-full bg-[#1e1e1e] flex flex-col">
            <textarea 
                value={code[activeFile]}
                onChange={(e) => setCode(prev => ({ ...prev, [activeFile]: e.target.value }))}
                className="w-full h-full p-4 bg-transparent text-gray-300 font-mono text-sm leading-relaxed resize-none focus:outline-none"
                spellCheck="false"
            />
        </div>
    );
  };

  return (
    <div className="flex flex-col h-screen bg-gray-900">
      <header className="flex-shrink-0 flex items-center justify-between p-2 bg-black border-b border-gray-800 text-sm">
        <div className="flex items-center gap-4">
            <h1 className="text-lg font-bold">Azan Builder</h1>
            <button onClick={onNewProject} className="px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded">New Project</button>
        </div>
        <div className="flex items-center gap-4">
            <button onClick={handleDownload} className="flex items-center gap-2 px-4 py-2 bg-white text-black font-semibold rounded-md hover:bg-gray-200">
                <Icon name="download" className="w-4 h-4" /> Download
            </button>
        </div>
      </header>

      <div className="flex flex-grow overflow-hidden">
        <aside className="w-64 bg-gray-900 border-r border-gray-800 p-4 flex flex-col">
            <h2 className="text-xs font-bold uppercase text-gray-500 mb-4">Files</h2>
            <div className="space-y-1 flex-grow overflow-y-auto">
               {Object.keys(code).map(fileName => (
                 <button 
                    key={fileName}
                    onClick={() => { setViewMode('code'); setActiveFile(fileName)}} 
                    className={`w-full text-left px-2 py-1.5 rounded text-sm break-all ${activeFile === fileName && viewMode === 'code' ? 'bg-gray-700' : 'hover:bg-gray-800'}`}>
                    {fileName}
                </button>
               ))}
            </div>
             <div className="mt-auto border-t border-gray-700 pt-4">
                <h3 className="text-xs font-bold uppercase text-gray-500 mb-2">Request Changes</h3>
                <textarea 
                    value={changeRequest}
                    onChange={e => setChangeRequest(e.target.value)}
                    placeholder="e.g., Change the theme to dark blue..."
                    className="w-full p-2 bg-gray-800 border border-gray-700 rounded-md text-xs resize-none focus:ring-1 focus:ring-white focus:outline-none"
                    rows={4}
                />
                <button
                    onClick={handleRegenerate}
                    disabled={!changeRequest.trim() || isRegenerating}
                    className="w-full mt-2 py-2 px-4 bg-gray-600 text-white font-semibold rounded-md hover:bg-gray-500 text-sm disabled:bg-gray-700 disabled:cursor-not-allowed"
                >
                    {isRegenerating ? 'Applying Changes...' : 'Re-generate'}
                </button>
            </div>
        </aside>

        <main className="flex-1 flex flex-col bg-black">
          <div className="flex-shrink-0 flex items-center justify-between p-2 border-b border-gray-800">
            <div className="flex items-center gap-2">
                <button onClick={handleReload} title="Reload Preview" className="p-2 hover:bg-gray-700 rounded"><Icon name="reload" className="w-5 h-5" /></button>
            </div>
            <div className="flex items-center gap-1 bg-gray-800 rounded-md p-1">
              {(['mobile', 'tablet', 'desktop'] as Device[]).map(d => (
                <button key={d} onClick={() => setDevice(d)} title={`View as ${d}`} className={`p-2 rounded ${device === d ? 'bg-gray-600' : 'hover:bg-gray-700'}`}>
                    <Icon name={d} className="w-5 h-5"/>
                </button>
              ))}
            </div>
            <div className="flex items-center gap-1 bg-gray-800 rounded-md p-1">
                <button onClick={() => setViewMode('code')} className={`px-3 py-1 flex items-center gap-2 rounded ${viewMode === 'code' ? 'bg-gray-600' : 'hover:bg-gray-700'}`}>
                    <Icon name="code" className="w-4 h-4"/> Code
                </button>
                <button onClick={() => setViewMode('preview')} className={`px-3 py-1 flex items-center gap-2 rounded ${viewMode === 'preview' ? 'bg-gray-600' : 'hover:bg-gray-700'}`}>
                    <Icon name="eye" className="w-4 h-4" /> Preview
                </button>
            </div>
          </div>
          <div className="flex-grow flex items-center justify-center p-4 bg-black overflow-auto">
            {viewMode === 'preview' ? (
              <iframe
                id="preview-iframe"
                srcDoc={previewContent}
                title="Live Preview"
                className="bg-white shadow-lg transition-all duration-300 border-0 rounded-md"
                style={{ width: deviceWidths[device], height: '100%' }}
                sandbox="allow-scripts allow-same-origin"
              />
            ) : (
                <CodeEditor />
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default BuilderPage;