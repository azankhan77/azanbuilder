
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="w-full py-6 text-center text-gray-500">
      <p>Created by Azan</p>
    </footer>
  );
};

export default Footer;
